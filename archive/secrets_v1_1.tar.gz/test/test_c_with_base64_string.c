#include <stdio.h>
#include <string.h>
// secrets.py test binary source
char *get_super_duper(char*);
char *find_hashes(int);

int main(void){
  char buff[5];
  char *secret_no_pad = "eW91ciBtb20K"; //"your mom"
  char *secret_with_pad = "eW91ciBtb20gCg=="; //"your mom "
  char *super_secret = "MTg2Mzk5MzA1NWQ3ZGJlYzkxMGZmODAwYzViODA5ZmMgIC0K"; // "your mom" | md5sum | base64
  //echo "secret string..shh" | base64 >> c2VjcmV0IHN0cmluZy4uc2hoCg==  with '==' removed
  char *sha1sumstring = "da353ad69fb3ec9efa6d30d91dd7882a841d9ca6"; // "your mom | sha1sum
  char super_duper_secret[29] = "c2VjcmV0IHN0cmluZy4uc2hoCg";

  printf("Hello! Enter 'p' for padded, 'n' for no pad, or 's' for super secret: \n");
  fgets(buff,4,stdin);
  
  if(buff[0] == 'p'){
    printf("Secret with padding: %s", secret_with_pad);
    printf("\n");
  }else if(buff[0] == 'n'){
    printf("Secret without padding: %s", secret_no_pad);
    printf("\n");
  }else if(buff[0] == 's'){
    printf("Super secret: %s", super_secret);
    printf("\n");
  }else{
    printf("you're a moron aren't you?\n");
  }
  printf(get_super_duper(super_duper_secret));
  printf("\n");
  printf(find_hashes(3));
  printf("\n");
  return 0;
}

char *get_super_duper(char *str){
  return strcat(str, "==");
}
  
char *find_hashes(int opt){
    char *sha256string = "9c2d9454aad8efe729c2914968efbf7145f2eaaf3d3c1f74f3b29ca1bc3603db";
    char *sha512string = "9974d80b9a1ca5d3c5891dcef772ea712fc35726f981e6bd6a76f580caa477b564ab3b752b13c9d90c4e410ab7f2b45dc0220ef7c3caf8fc7b268e81f0877e53";
    char *base64string = "aGV5dGhlcmUK";
    if(opt == 0){
        return sha256string;
    }else if(opt == 1){
        return sha512string;
    }else{
        return base64string;
    }
}    